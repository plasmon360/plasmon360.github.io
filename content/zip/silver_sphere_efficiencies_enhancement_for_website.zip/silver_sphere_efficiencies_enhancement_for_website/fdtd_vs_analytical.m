analytical=load('bhmie_analytical/analytical.dat');
fdtd=load('fdtd.dat');
if 1
plot(analytical(:,1),analytical(:,2:end),...
fdtd(:,1),fdtd(:,2),'s',...
fdtd(:,1),fdtd(:,3),'*',...
fdtd(:,1),fdtd(:,4),'o');
legend('Scattering-Analytical','Extinction-Analytical','Absorption-Analytical','Scattering-Meep','Extinction-Meep','Absorption-Meep')
title('Scattering/Absorption/Extinction Efficiencies for a silver sphere using MEEP and analytical solution')
xlabel('Wavelength (nm)')
ylabel('Efficiencies')
print('silver_meepvsanalytical.png','-dpng','-r100') 
else
plot(analytical(:,1),analytical(:,4),...
fdtd(:,1),fdtd(:,4),'o');
legend('Absorption-Analytical''Absorption-Meep')
title('Absorption for a silver sphere using MEEP and analytical solution')
xlabel('Wavelength (nm)')
ylabel('Efficiencies')
print('silver_meepvsanalytical_resl.png','-dpng','-r100') 
end
