
clear all 
close all;

data=load('variable_file.txt')
a=data(1)
rad=data(2)
resl=data(3)
fcen=data(4)
df=data(5)
nfreq=data(6)
sample=data(7)

N=2;

f_max=fcen+df/2
f_min=fcen-df/2
%Make sure f_max and f_min is a subset of fcen+df/2 and fcen-df/2

a=a*1e-9
c_vac=3e8; % velocity of light in vaccuum
% Load the data

evalxz=[1,0];
evalxy=[0,1];


for ii =[1,2]

if (evalxz(ii)==1)
load("sphere_silver-bEx_xz.h5");
load("sphere_silver-bEy_xz.h5");
load("sphere_silver-bEz_xz.h5");
exb=ex;
eyb=ey;
ezb=ez;
clear ex ey ez ;

load("sphere_silver-sEx_xz.h5");
load("sphere_silver-sEy_xz.h5");
load("sphere_silver-sEz_xz.h5");
exs=ex;
eys=ey;
ezs=ez;
clear ex ey ez ;
end

if (evalxy(ii)==1)
load("sphere_silver-bEx_xy.h5");
load("sphere_silver-bEy_xy.h5");
load("sphere_silver-bEz_xy.h5");
exb=ex;
eyb=ey;
ezb=ez;
clear ex ey ez ;

load("sphere_silver-sEx_xy.h5");
load("sphere_silver-sEy_xy.h5");
load("sphere_silver-sEz_xy.h5");
exs=ex;
eys=ey;
ezs=ez;
clear ex ey ez ;
end


T_units=a/((fcen+df/2)*c_vac)/sample; % Time units in secs
simulation_timeb=[1:size(exb,1)]*T_units; 
simulation_times=[1:size(exs,1)]*T_units; 






disp('Computing teh FFT of Ex of base simulation');
fflush(stdout);
NFFTb=2^nextpow2(N*length(simulation_times)); %even for base we are using structure time units
Yb=fft(exb,NFFTb,1)/length(simulation_times);%
exbw=2*abs(Yb(1:NFFTb/2+1,:,:));

disp('Computes the FFT of Ey of base simulation');
fflush(stdout);
Yb=fft(eyb,NFFTb,1)/length(simulation_times);%
eybw=2*abs(Yb(1:NFFTb/2+1,:,:));
clear Yb

disp('Computes the FFT of Ez of base simulation');
fflush(stdout);
Yb=fft(ezb,NFFTb,1)/length(simulation_times);%
ezbw=2*abs(Yb(1:NFFTb/2+1,:,:));
clear Yb

disp('Computing teh FFT of Ex of structure simulation');
fflush(stdout);
NFFTs=2^nextpow2(N*length(simulation_times)); 
Yb=fft(exs,NFFTs,1)/length(simulation_times);
exsw=2*abs(Yb(1:NFFTs/2+1,:,:));

disp('Computes the FFT of Ey of structure  simulation');
fflush(stdout);
Yb=fft(eys,NFFTs,1)/length(simulation_times);
eysw=2*abs(Yb(1:NFFTs/2+1,:,:));
clear Yb

disp('Computes the FFT of Ez of structure  simulation');
fflush(stdout);
Yb=fft(ezs,NFFTs,1)/length(simulation_times);
ezsw=2*abs(Yb(1:NFFTs/2+1,:,:));
clear Yb


disp('Prepares the lambda scale of the base simulation');
fflush(stdout);
fb=0.5*(1/T_units)*linspace(0,1,NFFTb/2+1);
fb_meep=fb/(c_vac/a);
lam_b_nm=c_vac*fb.^-1*1e9;

interestb=logical(fb_meep<=f_max & fb_meep>=f_min);
fb_meep=fb_meep(interestb);
lam_b_nm=lam_b_nm(interestb);


disp('Prepares the lambda scale of the structure simulation');
fflush(stdout);
fs=0.5*(1/T_units)*linspace(0,1,NFFTs/2+1);
fs_meep=fs/(c_vac/a);
lam_s_nm=c_vac*fs.^-1*1e9;

interests=logical(fs_meep<=f_max & fs_meep>=f_min);
fs_meep=fs_meep(interests);
lam_s_nm=lam_s_nm(interests);


exbw=exbw(interests,:,:);
eybw=eybw(interests,:,:);
ezbw=ezbw(interests,:,:);

exsw=exsw(interests,:,:);
eysw=eysw(interests,:,:);
ezsw=ezsw(interests,:,:);

disp('Calculate |E|^2 for structure simulation at frequencies of interest');
fflush(stdout);
%calculate |Eo|^2 for base simulation at frequencies of itnerest
for i=1:1:length(fb_meep)
ebw(i,:,:)=(abs(exbw(i,:,:).^2+eybw(i,:,:).^2+ezbw(i,:,:).^2));
end
%calculate |Eo|^2 for structure simulation at frequencies of itnerest
for i=1:1:length(fs_meep)
esw(i,:,:)=(abs(exsw(i,:,:).^2+eysw(i,:,:).^2+ezsw(i,:,:).^2));
end



%Calculate |E|^2/|Eo|^2 at frequencies of itnerest
for i=1:1:size(ebw,1)
enw(i,:,:)=esw(i,:,:)./ebw(i,:,:);
end

%save('normal_field_E_xz.h5','enw','-hdf5')
%system('h5topng -t 0:100 -S4 -Rc pm3d7575 normal_field_xz.h5:enw/value')



disp('Find the frequency and spatial point of maximum electric field (E(omega)^2) in the structure simulation');
fflush(stdout);
[rw,cw]=find(enw==max(enw(:)));
[r1w,c1w]=ind2sub([size(enw,2), size(enw,3)],cw(1));
disp('Maximum electric field enahncement happens') ;
disp('at x pixel=');;
disp(r1w);
disp('at y pixel=');
disp(c1w);
disp('at wavelength (nm)=') ;
disp(lam_s_nm(rw(1)))

x=linspace(0,1,128);r = sqrt(x);g = x.^3.0;b=sin(x*2*pi);b(b<0)=0;mycolormap=[r;g;b]';
y=linspace(0,[size(enw,2)-1]*a/resl,size(enw,2)); % Convert pixels to real units
x=linspace(0,[size(enw,3)-1]*a/resl,size(enw,3));% Convert pixels to real units
x=x-x(end)/2;% center the data
y=y-y(end)/2;% center the data
imagesc(x*1e9,y*1e9,log10(squeeze(enw(rw(1),:,:)))); shading interp;
axis equal
xlabel('x (nm)');

if (evalxz(ii)==1)
ylabel('z (nm)');
end
if (evalxy(ii)==1)
ylabel('y (nm)');
end


colormap(mycolormap)
t=colorbar;% Inserts a colorbar. a handle is created
set(get(t,'ylabel'),'string','log_{10}(|E/Eo|^2)','Fontsize',10) % sets the ylabel property of the handle t.



if (evalxz(ii)==1)
temp3=strcat('E_field_',num2str(lam_s_nm(rw(1))),'_nm_xz','.png');
print(temp3,'-dpng','-r100','-S800,600') ;
end
if (evalxy(ii)==1)
temp3=strcat('E_field_',num2str(lam_s_nm(rw(1))),'_nm_xy','.png');
print(temp3,'-dpng','-r100','-S800,600') ;
end

figure
disp('Plotting Maximum electric field enhancements vs lambda');
fflush(stdout);

plot(lam_s_nm,enw(:,r1w(1),c1w(1)),'-o')
xlabel('Wavelength (nm)')
ylabel('Maximum |E/Eo|^2 in xz plane')
%temp1=strcat('E^2_vs_lam_ar',num2str(aspect_ratio),'_pw',num2str(pw),'_resl',num2str(resl),'.dat');
%temp2=[lam_s_nm2',enw(:,r1w(1),c1w(1))];
%save(temp1,'temp2','-ascii');

if (evalxz(ii)==1)
print('electric_field_enhancment_xz.png','-dpng','-r100');
end

if (evalxy(ii)==1)
print('electric_field_enhancment_xy.png','-dpng','-r100');
end

if (1)

temp4=squeeze(enw(rw(1),:,:));
phi = linspace(0,2*pi,40); 
phi = phi(1:(length(phi)-1)); 	% 2pi and 0 are the same, we remove the last point
phi=fliplr(phi);

for jj=1:length(phi)
    temp5(:,:,jj)=real(exp(-1i*phi(jj))*temp4');
end

for jj=1:length(phi)
    fgh=figure('visible','off');
    
 imagesc(x*1e9,y*1e9,log10(abs(real(temp5(:,:,jj)))))
   caxis([0.5*min(log10(abs(real((temp5(:)))))),0.5*max(log10(abs(real((temp5(:))))))])
%   set(get(t,'ylabel'),'string','log_{10}(abs|E/Eo|^2)','Fontsize',10) % sets the ylabel property of the handle t.

    shading interp

colormap(mycolormap)
   colorbar;
    title('Electric Field (log scale) at plasmon resonance as function of time')
axis equal


if (evalxz(ii)==1)
xlabel('z (nm)');
ylabel('x (nm)');
end
if (evalxy(ii)==1)
xlabel('y (nm)');
ylabel('x (nm)');
end

    if jj<10
        file_name=strcat('00',num2str(jj),{'.png'});
    elseif jj<100
      file_name=strcat('0',num2str(jj),{'.png'});  
    elseif jj<1000
        file_name=strcat(num2str(jj),{'.png'});
    end
    
    print(file_name{1,1},'-dpng','-r100','-S800,600')
end% Ex_xzmonit=squeeze(Ex_xzmonit);
system('mogrify -trim +repage *.png')

system('for file in  0*.png ; do  `convert $file -font Helvetica -fill White -pointsize 25 -annotate +200+400 "http://juluribk.com"  $file`; done')

if (evalxz(ii)==1)
command1=strcat({'convert 0*.png '}, strcat('xz','.gif'))
end
if (evalxy(ii)==1)
command1=strcat({'convert 0*.png '}, strcat('xy','.gif'))
end

system(command1{1,1})
end
 system('rm 0*.png')


end



