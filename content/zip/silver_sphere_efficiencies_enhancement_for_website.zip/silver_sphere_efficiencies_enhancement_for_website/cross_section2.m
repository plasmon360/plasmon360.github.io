clear all 
close all;

data=load('variable_file.txt')
a=data(1)
rad=data(2)
resl=data(3)
fcen=data(4)
df=data(5)
nfreq=data(6)
sample=data(7)


sx1=rad*4
sz1=rad*4
area=sx1*sz1*a^2
sphere_area=pi*(rad*a)^2

no_structure=load('incident_flux.dat'); 
incident_pow=(no_structure(:,2))/area;
freq=no_structure(:,1);
lam=a*freq.^-1;




absorption=load('trans_flux_structure_abs.dat');
abs_pow=(-absorption(:,2)+absorption(:,3)-absorption(:,4)+absorption(:,5)-absorption(:,6)+absorption(:,7));
abs_cross_section=abs_pow./incident_pow;



scattering=load('trans_flux_structure_scat.dat');
scat_pow=-(-scattering(:,2)+scattering(:,3)-scattering(:,4)+scattering(:,5)-scattering(:,6)+scattering(:,7));
scat_cross_section=scat_pow./incident_pow;



%plot(lam(lam>300&lam<500),a*cross_section(lam>300&lam<500),'-o');
plot(lam,[scat_cross_section,(scat_cross_section+abs_cross_section),abs_cross_section]./sphere_area,'-o')
legend('Scattering','Extinction','Absorption')
ylabel('Efficiencies')
xlabel('Wavelength (nm)')


temp=[lam,scat_cross_section/sphere_area,(scat_cross_section+abs_cross_section)/sphere_area,abs_cross_section/sphere_area];

save('fdtd.dat','temp','-ascii')
