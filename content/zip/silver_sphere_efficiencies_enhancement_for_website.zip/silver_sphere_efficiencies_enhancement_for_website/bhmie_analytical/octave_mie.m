% Purpose of this code is to write a fort.11 input file for bhcyl executable, execute bhcyl and then read the output from fort.12. This is done for a series of wavelengths. Used LD.m code for generating the refractive indices of Silver using Lorentz-Drude model. The outout of bhcyl executable is scattering efficencies and extinction efficiencies. They need to converted scattering/extinction crossection per unit by multiplying with 2*Rad.
clear all

data=load('../variable_file.txt')
a=data(1)
rad=data(2)
resl=data(3)
fcen=data(4)
df=data(5)
nfreq=data(6)




rad=a*rad; % Should be in nanometers.
lam=[200:2:700]; % Should be in nanometers
[epsr,epsi,N]=LD(lam*1e-9,'Ag','LD');

for k=1:1:length(lam)
x=2*pi*rad/lam(k);
[s1,s2,qext,qsca,qback,gsca]=mie(x,N(k),2);
temp(:,k)=[qsca,qext,qext-qsca];
end
temp=temp';

plot(lam,temp)
xlabel('Wavelength (nm)')
ylabel('Efficiencies')
legend('Scattering','Extinction','Absorption')
temp2=[lam',temp(:,1),temp(:,2),temp(:,3)];
save('analytical.dat','temp2','-ascii')
print('silver_analytical.png','-dpng','-r100') 
